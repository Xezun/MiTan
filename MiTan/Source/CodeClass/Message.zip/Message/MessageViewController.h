//
//  MessageViewController.h
//  MiTan
//
//  Created by thl on 15/8/17.
//  Copyright (c) 2015年 thl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageViewController : UITableViewController

@end
