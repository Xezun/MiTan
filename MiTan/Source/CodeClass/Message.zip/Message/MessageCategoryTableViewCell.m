//
//  MessageCategoryTableViewCell.m
//  MiTan
//
//  Created by lanou3g on 15/8/20.
//  Copyright (c) 2015年 thl. All rights reserved.
//

#import "MessageCategoryTableViewCell.h"

@implementation MessageCategoryTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
