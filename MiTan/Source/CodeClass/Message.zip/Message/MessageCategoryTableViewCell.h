//
//  MessageCategoryTableViewCell.h
//  MiTan
//
//  Created by lanou3g on 15/8/20.
//  Copyright (c) 2015年 thl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageCategoryTableViewCell : UITableViewCell

@end
